

public class Usuario {

    protected String senha;

    public Usuario(String senha) {
 
        this.senha = senha;
    }

    public String getSenha() {
        return senha;
    }

}
