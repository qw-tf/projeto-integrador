import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// import javax.naming.InvalidNameException;
// import javax.swing.JOptionPane;
// import javax.swing.JPopupMenu;   


public class Estoque {

    private List<Produto> produtos = new ArrayList<>();
    Verificador verificador = new Verificador();

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void adicionarProduto(Scanner scanner) {
        String nome = "";
        int quantidade = 0;
        double preco = 0.0;
        String dataDeValidade = "";
        boolean ehPerecivel = false;
    
        try {
            GerarLogs.logAutomatic("Adicionando Produto");
    
            // Nome
            while (true) {
                System.out.println("Qual o nome do produto? (0 para sair)");
                nome = scanner.nextLine();
                if (nome.equals("0")) {
                    System.out.println("Saindo...");
                    GerarLogs.logAutomatic("Operacao Cancelada pelo usuario");
                    return;
                }
                try {
                    verificador.verificarNome(nome);
                    break;
                } catch (ValidacaoException e) {
                    System.out.println(e.getMessage());
                }
            }
    
            // Quantidade
            while (true) {
                System.out.println("Quanto tem desse produto?");
                try {
                    quantidade = Integer.parseInt(scanner.nextLine());
                    verificador.verificarQuantidade(quantidade);
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Erro, escreva um número inteiro corretamente!");
                } catch (ValidacaoException e) {
                    System.out.println(e.getMessage());
                }
            }
    
            // Preço
            while (true) {
                System.out.println("Qual o preco desse produto?");
                try {
                    preco = Double.parseDouble(scanner.nextLine());
                    verificador.verificarPreco(preco);
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Erro, escreva um número corretamente!");
                } catch (ValidacaoException e) {
                    System.out.println(e.getMessage());
                }
            }
    
            // É perecível?
            while (true) {
                System.out.println("O produto é perecivel? (s/n)");
                String opcao = scanner.nextLine().trim().toLowerCase();
                if (opcao.equals("s")) {
                    ehPerecivel = true;
                    break;
                } else if (opcao.equals("n")) {
                    ehPerecivel = false;
                    break;
                } else {
                    System.out.println("Opcao invalida! Digite 's' ou 'n'.");
                }
            }
    
            // Data de validade, se for perecível
            if (ehPerecivel) {
                while (true) {
                    System.out.println("Escreva a data de validade do produto (dd/mm/yyyy):");
                    dataDeValidade = scanner.nextLine();
                    try {
                        verificador.verificarDataValidade(dataDeValidade);
                        break;
                    } catch (ValidacaoException | DateTimeParseException e) {
                        System.out.println(e.getMessage());
                    }
                }
            }
    
            // Criar o produto e adicionar na lista
            Produto produto;
            if (ehPerecivel) {
                produto = new ProdutoPerecivel(nome, quantidade, preco, dataDeValidade);
            } else {
                produto = new Produto(nome, quantidade, preco);
            }
    
            produtos.add(produto);
            GerarLogs.logAutomatic("Produto cadastrado com sucesso!");
            System.out.println("Produto cadastrado com sucesso!");
    
        } catch (Exception e) {
            System.out.println("Erro inesperado: " + e.getMessage());
            scanner.nextLine();
        }
    }
    
    public void excluirProduto(Scanner scanner) {
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            GerarLogs.logAutomatic("Tentativa de excluir, mas lista vazia.");
            return;
        }
    
        while (true) {
            System.out.println("Produtos cadastrados:");
            for (Produto p : produtos) {
                System.out.println("Codigo: " + p.getCodigo() + ", Nome: " + p.getNome());
            }
    
            System.out.println("Digite o codigo do produto que quer excluir ou '0' para sair: ");
            String input = scanner.nextLine();
    
            if (input.equals("0")) {
                System.out.println("Saindo...");
                GerarLogs.logAutomatic("Remocao cancelada pelo usuario.");
                return;
            }
    
            try {
                int codigo = Integer.parseInt(input);
                verificador.verificarCodigo(codigo);
    
                Produto produtoParaExcluir = null;
                for (Produto p : produtos) {
                    if (p.getCodigo() == codigo) {
                        produtoParaExcluir = p;
                        break;
                    }
                }
    
                if (produtoParaExcluir == null) {
                    System.out.println("Produto com esse código não encontrado.");
                    GerarLogs.logAutomatic("Codigo nao encontrado na remocao.");
                    continue;
                }
    
                System.out.println("Tem certeza que quer excluir (" + produtoParaExcluir.getNome() + ") (s/n)?");
                String opcao = scanner.nextLine().trim().toLowerCase();
                if (opcao.equals("s")) {
                    produtos.remove(produtoParaExcluir);
                    System.out.println("Produto removido com sucesso.");
                    GerarLogs.logAutomatic("Produto removido.");
                    return;
                } else {
                    System.out.println("Remocao cancelada.");
                    GerarLogs.logAutomatic("Remocao cancelada.");
                    return;
                }
    
            } catch (NumberFormatException e) {
                System.out.println("Digite um código válido (número inteiro).");
            } catch (ValidacaoException e) {
                System.out.println(e.getMessage());
            }
        }
    }
    
            public void inserirLista(Produto produto) {
                produtos.add(produto); // metodo para aumentar a lista privada
            }

            public Produto buscarProduto(int codigo) throws ValidacaoException{
                for (Produto produto : produtos) { // temos lista percorrer
                    if (produto.getCodigo() == codigo) { // compara o nome do produto
                        return produto;
                    }
                }
                return null; // se n encontrar o produto, retorna null
            }

            public void removerProduto(int codigo, int quantidade) throws ValidacaoException {
                Produto produto = buscarProduto(codigo);
                if (produto != null) {
                    produto.setQuantidade((produto.getQuantidade() - quantidade));
                    System.out.println("Produto " + produto.getNome() + " atualizado no estoque. Nova quantidade: " + produto.getQuantidade());
                }
            }
        

    }