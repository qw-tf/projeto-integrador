

import javax.swing.*;

public class SistemaPrincipal {

    public static void main(String[] args) {

        GerenciadorSenha gerenciadorSenha = new GerenciadorSenha();

        while (true) {
            JOptionPane.showMessageDialog(null, "Bem-vindo");

            String[] options = {"Registrar Senha", "Alterar Senha", "Sair"};
            int escolha = JOptionPane.showOptionDialog(
                    null,
                    "Escolha uma opção:",
                    "Menu Principal",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);
 
            switch (escolha) {
                case 0 -> gerenciadorSenha.registrarSenha();
                case 1 -> gerenciadorSenha.alterarSenha();
                case 2 -> {
                    JOptionPane.showMessageDialog(null, "Saindo do sistema...");
                    return;
                }
                default -> {
                    JOptionPane.showMessageDialog(null, "Opção inválida ou cancelada. Encerrando.");
                    return;
                }
            }
        }
    }
}
