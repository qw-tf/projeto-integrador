
import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;

public class MenuLogin extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MenuLogin.class.getName());

    public MenuLogin() {
        initComponents();

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setResizable(true);
        getContentPane().setBackground(Color.WHITE);

        jLabelTitulo.setForeground(Color.BLACK);
        jLabelTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));

        jPasswordField.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        jPasswordField.setForeground(Color.BLACK);

        jButtonSair.setBackground(Color.BLACK);
        jButtonSair.setForeground(Color.RED);
        jButtonSair.setFont(new Font("Segoe UI", Font.BOLD, 14));

        jButtonEntrar.setBackground(Color.BLACK);
        jButtonEntrar.setForeground(Color.WHITE);
        jButtonEntrar.setFont(new Font("Segoe UI", Font.BOLD, 14));

        jButtonSair.addActionListener(e -> System.exit(0));
    }

    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jLabelTitulo = new javax.swing.JLabel();
        jPasswordField = new javax.swing.JPasswordField();
        jButtonSair = new javax.swing.JButton();
        jButtonEntrar = new javax.swing.JButton();

         setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(800, 450));
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jLabelTitulo.setText("DIGITE SUA SENHA");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(103, 170, 0, 162);
        getContentPane().add(jLabelTitulo, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.ipadx = 130;
        gridBagConstraints.ipady = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(34, 224, 0, 0);
        getContentPane().add(jPasswordField, gridBagConstraints);

        jButtonEntrar.setText("CONTINUAR");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 19;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(34, 230, 0, 0);
        getContentPane().add(jButtonEntrar, gridBagConstraints);

        jButtonSair.setText("SAIR");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.ipadx = 73;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(16, 230, 0, 0);
        getContentPane().add(jButtonSair, gridBagConstraints);

        pack();
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new MenuLogin().setVisible(true));
    }

    // Variáveis
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonEntrar;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPasswordField jPasswordField;
}
