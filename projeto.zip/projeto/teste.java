import javax.swing.JOptionPane;

public class teste {

    public static void main(String[] args) {
        String senha = "";
        while (true) {
            JOptionPane.showMessageDialog(null, "teste social");
            String[] options = {"teste1", "teste2", "teste3", "mostrar os fodase", "sair dos fodase"};
            int escolha = JOptionPane.showOptionDialog(
                    null,
                    "os testes",
                    "titulo teste",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            switch (escolha) {
                case 0 -> senha = JOptionPane.showInputDialog(null, "fodase1");
                case 1 -> JOptionPane.showMessageDialog(null, "fodase2");
                case 2 -> JOptionPane.showMessageDialog(null, "fodase3");
                case 3 -> JOptionPane.showMessageDialog( null, "os tais: " + senha,"lista dos fodase",JOptionPane.INFORMATION_MESSAGE);
                case 4 -> {
                    JOptionPane.showMessageDialog(null, "saindo dos fodase...");
                    return;
                }
                
                default -> {
                    return;
                }
            }
        }
    }
}
