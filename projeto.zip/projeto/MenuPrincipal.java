import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JFrame;

public class MenuPrincipal extends JFrame {

    public MenuPrincipal() {
        initComponents();

        // Estilo geral da janela
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setResizable(true);
        getContentPane().setBackground(Color.WHITE); // Fundo branco

        // Título
        jLabel1.setForeground(Color.BLACK);
        jLabel1.setFont(new Font("Segoe UI", Font.BOLD, 24));

        // Estilo dos botões
        estilizarBotao(jButton1);
        estilizarBotao(jButton2);
        estilizarBotao(jButton3);
        estilizarBotao(jButton4);
        estilizarBotao(jButton5);
    }

    private void estilizarBotao(javax.swing.JButton botao) {
        botao.setBackground(Color.BLACK);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Segoe UI", Font.BOLD, 14));
    }

    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.anchor = GridBagConstraints.WEST;

        jLabel1.setText("O QUE DESEJA ACESSAR?");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        getContentPane().add(jLabel1, gbc);

        // Linha 1
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        getContentPane().add(jLabel2, gbc);
        jLabel2.setText("CONTROLE DE ESTOQUE");
        jLabel2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 1;
        getContentPane().add(jButton1, gbc);
        jButton1.setText("*");

        // Linha 2
        gbc.gridx = 0;
        gbc.gridy = 2;
        getContentPane().add(jLabel3, gbc);
        jLabel3.setText("CONTROLE DE VENDAS");
        jLabel3.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 1;
        getContentPane().add(jButton2, gbc);
        jButton2.setText("*");

        // Linha 3
        gbc.gridx = 0;
        gbc.gridy = 3;
        getContentPane().add(jLabel4, gbc);
        jLabel4.setText("CONTROLE DE FIADOS");
        jLabel4.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 1;
        getContentPane().add(jButton3, gbc);
        jButton3.setText("*");

        // Linha 4
        gbc.gridx = 0;
        gbc.gridy = 4;
        getContentPane().add(jLabel5, gbc);
        jLabel5.setText("GASTOS MENSAIS");
        jLabel5.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 1;
        getContentPane().add(jButton4, gbc);
        jButton4.setText("*");

        // Linha 5
        gbc.gridx = 0;
        gbc.gridy = 5;
        getContentPane().add(jLabel6, gbc);
        jLabel6.setText("BALANÇO GERAL");
        jLabel6.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gbc.gridx = 1;
        getContentPane().add(jButton5, gbc);
        jButton5.setText("*");

        pack();
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }

    // Declaração dos componentes
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
}
