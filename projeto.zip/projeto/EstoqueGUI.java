
import java.awt.*;
import javax.swing.*;

public class EstoqueGUI extends JFrame {

    Estoque estoque = new Estoque();

    public EstoqueGUI() {
        setTitle("Sistema de Estoque");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 1));

        JButton btnAdicionar = new JButton("Adicionar Produto");
        JButton btnRemover = new JButton("Remover Produto");
        JButton btnListar = new JButton("Listar Produtos");
        JButton btnSair = new JButton("Sair");

        btnAdicionar.addActionListener(e -> adicionarProduto());
        btnRemover.addActionListener(e -> removerProduto());
        btnListar.addActionListener(e -> listarProdutos());
        btnSair.addActionListener(e -> System.exit(0));

        add(btnAdicionar);
        add(btnRemover);
        add(btnListar);
        add(btnSair);

        setVisible(true);
    }

    private void adicionarProduto() {
        try {
            String nome = JOptionPane.showInputDialog("Digite o nome do produto:");
            if (nome == null) return; // Cancelado
            estoque.verificador.verificarNome(nome);

            String quantidadeStr = JOptionPane.showInputDialog("Digite a quantidade:");
            int quantidade = Integer.parseInt(quantidadeStr);
            estoque.verificador.verificarQuantidade(quantidade);

            String precoStr = JOptionPane.showInputDialog("Digite o preço:");
            double preco = Double.parseDouble(precoStr);
            estoque.verificador.verificarPreco(preco);

            int perecivel = JOptionPane.showConfirmDialog(null, "O produto é perecível?", "Perecível", JOptionPane.YES_NO_OPTION);
            Produto produto;

            if (perecivel == JOptionPane.YES_OPTION) {
                String data = JOptionPane.showInputDialog("Digite a data de validade (dd/mm/yyyy):");
                estoque.verificador.verificarDataValidade(data);
                produto = new ProdutoPerecivel(nome, quantidade, preco, data);
            } else {
                produto = new Produto(nome, quantidade, preco);
            }

            estoque.inserirLista(produto);
            JOptionPane.showMessageDialog(null, "Produto cadastrado com sucesso!");

        } catch (ValidacaoException e) {
            JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Erro: Digite um número válido.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro inesperado: " + e.getMessage());
        }
    }

    private void removerProduto() {
        try {
            String codigoStr = JOptionPane.showInputDialog("Digite o código do produto para remover:");
            int codigo = Integer.parseInt(codigoStr);

            Produto produto = estoque.buscarProduto(codigo);
            if (produto == null) {
                JOptionPane.showMessageDialog(null, "Produto não encontrado.");
                return;
            }

            int confirmar = JOptionPane.showConfirmDialog(null, "Deseja remover o produto: " + produto.getNome() + "?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (confirmar == JOptionPane.YES_OPTION) {
                estoque.getProdutos().remove(produto);
                JOptionPane.showMessageDialog(null, "Produto removido.");
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Código inválido.");
        } catch (ValidacaoException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    private void listarProdutos() {
        if (estoque.getProdutos().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum produto cadastrado.");
            return;
        }

        StringBuilder lista = new StringBuilder();
        for (Produto p : estoque.getProdutos()) {
            lista.append("Código: ").append(p.getCodigo())
                 .append(", Nome: ").append(p.getNome())
                 .append(", Quantidade: ").append(p.getQuantidade())
                 .append(", Preço: ").append(p.getPreco());

            if (p instanceof ProdutoPerecivel) {
                lista.append(", Validade: ").append(((ProdutoPerecivel) p).getDataDeValidade());
            }

            lista.append("\n");
        }

        JOptionPane.showMessageDialog(null, lista.toString());
    }

    public static void main(String[] args) {
        new EstoqueGUI();
    }
}