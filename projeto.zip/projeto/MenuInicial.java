import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JFrame;

public class MenuInicial extends JFrame {

    public MenuInicial() {
        initComponents();

        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setResizable(true);
        getContentPane().setBackground(Color.WHITE);

        jButton3.setBackground(Color.BLACK);
        jButton3.setForeground(Color.WHITE);
        jButton3.setFont(new Font("Segoe UI", Font.BOLD, 14));
        jButton3.addActionListener(e -> {
            new MenuLogin().setVisible(true); // Abre a janela de login
            this.dispose(); // Fecha o MenuPrincipal (se quiser manter aberto, remova essa linha)
        });

        jButton5.setBackground(Color.BLACK);
        jButton5.setForeground(Color.RED);
        jButton5.setFont(new Font("Segoe UI", Font.BOLD, 14));
        jButton5.addActionListener(e -> System.exit(0));

        jLabel1.setForeground(Color.BLACK);
        jLabel1.setFont(new Font("Segoe UI", Font.BOLD, 24));
    }

    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jButton6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        jButton6.setText("jButton6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(400, 400));
        getContentPane().setLayout(new GridBagLayout());

        jLabel1.setText("SEJA BEM-VINDO");
        jLabel1.setAlignmentY(0.0F);
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new Insets(103, 170, 0, 162);
        getContentPane().add(jLabel1, gridBagConstraints);

        jButton3.setText("ENTRAR");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipadx = 7;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.insets = new Insets(34, 220, 0, 0);
        getContentPane().add(jButton3, gridBagConstraints);

        jButton5.setText("SAIR");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 42;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new Insets(6, 220, 170, 0);
        getContentPane().add(jButton5, gridBagConstraints);

        pack();
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(MenuInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new MenuInicial().setVisible(true));
    }

    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
}
